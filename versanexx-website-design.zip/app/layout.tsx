import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"
import { Suspense } from "react"

export const metadata: Metadata = {
  title: "Versanexx — Software House | Web, Mobile, AI & Cloud Solutions",
  description:
    "Versanexx is a full-service software house delivering modern web, mobile, AI, and cloud solutions. We build fast, scalable products with a human-centered approach.",
  generator: "v0.app",
  keywords: [
    "Versanexx",
    "software house",
    "web development",
    "mobile apps",
    "AI",
    "cloud",
    "Next.js",
    "Tailwind CSS",
    "Framer Motion",
  ],
  openGraph: {
    title: "Versanexx — Software House",
    description: "We craft high-performance digital products: Web, Mobile, AI & Cloud.",
    url: "https://versanexx.example", // replace when live
    siteName: "Versanexx",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Versanexx — Software House",
    description: "Modern Web, Mobile, AI & Cloud solutions. Fast. Scalable. Human-centered.",
    creator: "@versanexx", // update if available
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable}`}>
        <Suspense fallback={null}>{children}</Suspense>
        <Analytics />
      </body>
    </html>
  )
}
