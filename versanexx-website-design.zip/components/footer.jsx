"use client"
import { FiTwitter, FiInstagram, FiLinkedin } from "react-icons/fi"

export default function Footer() {
  return (
    <footer className="border-t">
      <div className="mx-auto max-w-7xl px-4 py-8 md:px-6">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-md bg-primary" aria-hidden />
            <span className="text-sm font-semibold">Versanexx</span>
          </div>
          <ul className="flex items-center gap-4 text-muted-foreground">
            <li>
              <a href="#" aria-label="Twitter">
                <FiTwitter className="h-5 w-5" />
              </a>
            </li>
            <li>
              <a href="#" aria-label="Instagram">
                <FiInstagram className="h-5 w-5" />
              </a>
            </li>
            <li>
              <a href="#" aria-label="LinkedIn">
                <FiLinkedin className="h-5 w-5" />
              </a>
            </li>
          </ul>
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Versanexx. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
