"use client"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"
import { FiCpu, FiSmartphone, FiCloud, FiShoppingCart, FiBarChart2, FiShield } from "react-icons/fi"

const services = [
  { icon: FiCpu, title: "Web Apps", desc: "High-performance web applications using Next.js." },
  { icon: FiSmartphone, title: "Mobile Apps", desc: "Cross-platform mobile experiences that delight users." },
  { icon: FiCloud, title: "Cloud & DevOps", desc: "Scalable infrastructure, CI/CD, observability & security." },
  { icon: FiShoppingCart, title: "E‑commerce", desc: "Conversion-focused storefronts, payments & subscriptions." },
  { icon: FiBarChart2, title: "AI & Analytics", desc: "Data-driven products, insights and automation." },
  { icon: FiShield, title: "Security & Audits", desc: "Security-first engineering and performance audits." },
]

export default function Services() {
  return (
    <section id="services" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="What We Do" title="Services tailored to your goals" />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ icon: Icon, title, desc }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.45, delay: i * 0.05 }}
              className="group rounded-lg border p-5 hover:shadow-sm"
            >
              <div className="flex items-start gap-3">
                <div className="rounded-md bg-accent/20 p-2 text-accent">
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">{title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
