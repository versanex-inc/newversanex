"use client"
import { useState } from "react"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"

export default function Contact() {
  const [submitting, setSubmitting] = useState(false)

  async function onSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      // Simulate submission; replace with API route if needed
      await new Promise((r) => setTimeout(r, 800))
      alert("Thanks! We’ll be in touch shortly.")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <section id="contact" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="Get in Touch" title="Let’s build something great" />
        <motion.form
          onSubmit={onSubmit}
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.45 }}
          className="mx-auto mt-10 grid max-w-2xl gap-4 rounded-lg border p-5"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <label htmlFor="name" className="text-sm font-medium">
                Name
              </label>
              <input id="name" name="name" required className="rounded-md border px-3 py-2" placeholder="Your name" />
            </div>
            <div className="grid gap-2">
              <label htmlFor="email" className="text-sm font-medium">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                className="rounded-md border px-3 py-2"
                placeholder="you@company.com"
              />
            </div>
          </div>
          <div className="grid gap-2">
            <label htmlFor="message" className="text-sm font-medium">
              Project details
            </label>
            <textarea
              id="message"
              name="message"
              rows={5}
              required
              className="rounded-md border px-3 py-2"
              placeholder="Tell us about your goals…"
            />
          </div>
          <div className="flex items-start gap-2">
            <input id="consent" type="checkbox" required className="mt-1" />
            <label htmlFor="consent" className="text-sm text-muted-foreground">
              I agree to the processing of my personal data as described in the privacy policy.
            </label>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-60"
            >
              {submitting ? "Sending…" : "Send Message"}
            </button>
          </div>
        </motion.form>
      </div>
    </section>
  )
}
