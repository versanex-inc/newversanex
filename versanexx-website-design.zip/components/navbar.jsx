"use client"
import { useState, useEffect } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  FiMenu,
  FiX,
  FiLayers,
  FiCode,
  FiSmartphone,
  FiCpu,
  FiCloud,
  FiPenTool,
  FiInfo,
  FiUsers,
  FiBriefcase,
} from "react-icons/fi"
import {
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuTrigger,
  NavigationMenuContent,
} from "@/components/ui/navigation-menu"
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu"

const services = [
  {
    icon: FiCode,
    title: "Web Apps",
    desc: "High-performance, SEO-friendly Next.js apps.",
    href: "#services",
  },
  {
    icon: FiSmartphone,
    title: "Mobile Apps",
    desc: "Cross-platform apps with smooth UX.",
    href: "#services",
  },
  {
    icon: FiCpu,
    title: "AI & Automation",
    desc: "Integrations, agents, and workflow automation.",
    href: "#services",
  },
  {
    icon: FiCloud,
    title: "Cloud & DevOps",
    desc: "Scalable infra, CI/CD, and observability.",
    href: "#services",
  },
  {
    icon: FiPenTool,
    title: "UI/UX Design",
    desc: "Human-centered, conversion-focused design.",
    href: "#services",
  },
  {
    icon: FiLayers,
    title: "E-commerce",
    desc: "Headless storefronts with Stripe.",
    href: "#services",
  },
]

const projects = [
  { label: "All Projects", href: "#work" },
  { label: "Web Applications", href: "#work" },
  { label: "Mobile Applications", href: "#work" },
  { label: "AI & ML", href: "#work" },
  { label: "E-commerce", href: "#work" },
]

const aboutItems = [
  { icon: FiInfo, label: "Who We Are", href: "#about" },
  { icon: FiUsers, label: "Team", href: "#team" },
  { icon: FiBriefcase, label: "Careers", href: "#contact" },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener("scroll", onScroll)
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all ${scrolled ? "bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b shadow-[0_6px_30px_-10px_rgba(0,0,0,0.25)]" : ""}`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 md:px-6">
        <Link href="/" className="group flex items-center gap-2" aria-label="Versanexx home">
          <div
            className="h-8 w-8 rounded-md bg-primary shadow-md ring-1 ring-black/5 transition group-hover:scale-105"
            aria-hidden
          />
          <span className="text-lg font-semibold tracking-tight">Versanexx</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden items-center gap-2 md:flex">
          {/* About - dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger className="rounded-md px-3 py-2 text-sm hover:bg-accent/20 transition shadow-sm">
              About
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="min-w-56 rounded-lg shadow-xl">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Learn about us</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {aboutItems.map((a) => (
                <DropdownMenuItem key={a.label} asChild>
                  <a href={a.href} className="flex items-center gap-2">
                    <a.icon className="h-4 w-4 text-primary" aria-hidden />
                    <span>{a.label}</span>
                  </a>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Projects - dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger className="rounded-md px-3 py-2 text-sm hover:bg-accent/20 transition shadow-sm">
              Projects
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="min-w-56 rounded-lg shadow-xl">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Explore our work</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {projects.map((p) => (
                <DropdownMenuItem key={p.label} asChild>
                  <a href={p.href} className="block">
                    {p.label}
                  </a>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Services - mega menu */}
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger className="rounded-md px-3 py-2 text-sm hover:bg-accent/20 transition shadow-sm">
                  Services
                </NavigationMenuTrigger>
                <NavigationMenuContent className="rounded-xl shadow-2xl">
                  <div className="grid w-[720px] max-w-[90vw] grid-cols-2 gap-4 p-4 md:grid-cols-3">
                    {services.map((s) => (
                      <a
                        key={s.title}
                        href={s.href}
                        className="group rounded-lg border p-4 transition hover:-translate-y-0.5 hover:shadow-xl"
                      >
                        <div className="flex items-start gap-3">
                          <s.icon className="mt-1 h-5 w-5 text-primary" aria-hidden />
                          <div>
                            <p className="font-medium leading-tight">{s.title}</p>
                            <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
                          </div>
                        </div>
                      </a>
                    ))}
                  </div>
                </NavigationMenuContent>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>

          {/* Contact CTA */}
          <a
            href="#contact"
            className="ml-2 inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-md transition hover:shadow-lg hover:opacity-95"
          >
            Contact
          </a>
        </div>

        {/* Mobile trigger */}
        <button
          className="inline-flex md:hidden items-center justify-center rounded-md border px-3 py-2 shadow-sm"
          aria-label="Open menu"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen(true)}
        >
          <FiMenu className="h-5 w-5" />
        </button>
      </nav>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="fixed inset-0 z-50 bg-black/40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
            />
            <motion.aside
              id="mobile-menu"
              className="fixed right-0 top-0 z-50 h-full w-80 max-w-[85%] bg-background p-6 shadow-2xl"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 260, damping: 28 }}
              aria-label="Mobile navigation"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-7 w-7 rounded-md bg-primary shadow ring-1 ring-black/5" aria-hidden />
                  <span className="text-base font-semibold">Versanexx</span>
                </div>
                <button
                  className="rounded-md border p-2 shadow-sm"
                  aria-label="Close menu"
                  onClick={() => setOpen(false)}
                >
                  <FiX className="h-5 w-5" />
                </button>
              </div>

              {/* Collapsible groups */}
              <ul className="mt-6 space-y-3">
                {/* About group */}
                <li>
                  <details className="group rounded-md border">
                    <summary className="flex cursor-pointer list-none items-center justify-between px-3 py-2 text-sm">
                      <span className="inline-flex items-center gap-2">
                        <FiInfo className="h-4 w-4" /> About
                      </span>
                      <span className="transition group-open:rotate-180">▾</span>
                    </summary>
                    <div className="space-y-1 px-3 pb-3">
                      {aboutItems.map((a) => (
                        <a
                          key={a.label}
                          href={a.href}
                          onClick={() => setOpen(false)}
                          className="block rounded-md px-2 py-2 text-sm hover:bg-accent/20"
                        >
                          <span className="inline-flex items-center gap-2">
                            <a.icon className="h-4 w-4" /> {a.label}
                          </span>
                        </a>
                      ))}
                    </div>
                  </details>
                </li>

                {/* Projects group */}
                <li>
                  <details className="group rounded-md border">
                    <summary className="flex cursor-pointer list-none items-center justify-between px-3 py-2 text-sm">
                      <span>Projects</span>
                      <span className="transition group-open:rotate-180">▾</span>
                    </summary>
                    <div className="space-y-1 px-3 pb-3">
                      {projects.map((p) => (
                        <a
                          key={p.label}
                          href={p.href}
                          onClick={() => setOpen(false)}
                          className="block rounded-md px-2 py-2 text-sm hover:bg-accent/20"
                        >
                          {p.label}
                        </a>
                      ))}
                    </div>
                  </details>
                </li>

                {/* Services group */}
                <li>
                  <details className="group rounded-md border">
                    <summary className="flex cursor-pointer list-none items-center justify-between px-3 py-2 text-sm">
                      <span>Services</span>
                      <span className="transition group-open:rotate-180">▾</span>
                    </summary>
                    <div className="grid grid-cols-1 gap-2 px-3 pb-3">
                      {services.map((s) => (
                        <a
                          key={s.title}
                          href={s.href}
                          onClick={() => setOpen(false)}
                          className="flex items-start gap-3 rounded-md border px-2 py-3 hover:bg-accent/10"
                        >
                          <s.icon className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
                          <div>
                            <p className="text-sm font-medium leading-tight">{s.title}</p>
                            <p className="text-xs text-muted-foreground">{s.desc}</p>
                          </div>
                        </a>
                      ))}
                    </div>
                  </details>
                </li>

                {/* Contact */}
                <li className="pt-2">
                  <a
                    href="#contact"
                    onClick={() => setOpen(false)}
                    className="block rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground shadow-md"
                  >
                    Contact
                  </a>
                </li>
              </ul>

              <p className="mt-6 text-xs text-muted-foreground">
                © {new Date().getFullYear()} Versanexx. All rights reserved.
              </p>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </header>
  )
}
