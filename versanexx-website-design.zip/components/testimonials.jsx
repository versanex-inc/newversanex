"use client"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"

const testimonials = [
  {
    name: "Ayesha K.",
    role: "Founder, Bloom",
    quote: "Versanexx delivered beyond expectations — fast, beautiful, and effective.",
  },
  {
    name: "Marcus L.",
    role: "CTO, Fineta",
    quote: "Expert team. Strong communication and quality engineering practices.",
  },
  {
    name: "Sofia R.",
    role: "PM, Orbit",
    quote: "They deeply understood our users and shipped on time. Highly recommended!",
  },
]

export default function Testimonials() {
  return (
    <section id="reviews" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="Client Reviews" title="What our clients say" />
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <motion.blockquote
              key={t.name}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.45, delay: i * 0.05 }}
              className="rounded-lg border p-5"
            >
              <p className="leading-relaxed">“{t.quote}”</p>
              <footer className="mt-3 text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{t.name}</span> — {t.role}
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  )
}
