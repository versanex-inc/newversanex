"use client"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"
import { FiPlayCircle } from "react-icons/fi"

const clips = Array.from({ length: 4 }).map((_, i) => ({
  id: i + 1,
  poster: `/placeholder.svg?height=600&width=800&query=instagram reel showcase ${i + 1}`,
  title: `Instagram Reel ${i + 1}`,
}))

export default function Instagram() {
  return (
    <section id="instagram" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="Instagram" title="Video & reels showcase" />
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {clips.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.45, delay: i * 0.05 }}
              className="group relative overflow-hidden rounded-lg border"
            >
              <img
                src={c.poster || "/placeholder.svg"}
                alt={`${c.title} thumbnail`}
                className="h-full w-full object-cover"
              />
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/0 transition group-hover:bg-black/10">
                <FiPlayCircle className="h-14 w-14 text-white drop-shadow" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
