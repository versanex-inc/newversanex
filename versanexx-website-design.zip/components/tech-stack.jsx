"use client"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"
import { SiNextdotjs, SiReact, SiTailwindcss, SiFramer, SiNodedotjs } from "react-icons/si"

const tech = [
  { icon: SiNextdotjs, label: "Next.js" },
  { icon: SiReact, label: "React" },
  { icon: SiTailwindcss, label: "Tailwind CSS" },
  { icon: SiFramer, label: "Framer Motion" },
  { icon: SiNodedotjs, label: "Node.js" },
]

export default function TechStack() {
  return (
    <section id="tech" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="Tools We Use" title="Modern, proven tech stack" />
        <div className="mt-8 grid grid-cols-2 items-center justify-items-center gap-6 sm:grid-cols-3 md:grid-cols-5">
          {tech.map(({ icon: Icon, label }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.4, delay: i * 0.04 }}
              className="flex flex-col items-center gap-2"
              aria-label={label}
            >
              <div className="rounded-lg border p-4">
                <Icon className="h-8 w-8" />
              </div>
              <span className="text-sm text-muted-foreground">{label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
