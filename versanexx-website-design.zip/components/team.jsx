"use client"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"

const team = [
  { name: "Arman Siddiqui", role: "CEO / Product", img: "/team-leader-portrait.png" },
  { name: "Sara Malik", role: "Design Lead", img: "/designer-portrait.png" },
  { name: "Usman Khan", role: "Engineering Lead", img: "/thoughtful-engineer.png" },
  { name: "Zara Hameed", role: "AI Engineer", img: "/ai-engineer-portrait.jpg" },
]

export default function Team() {
  return (
    <section id="team" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="Meet Our Experts" title="Team Spotlight" />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {team.map((m, i) => (
            <motion.div
              key={m.name}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.45, delay: i * 0.05 }}
              className="rounded-lg border p-4 text-center"
            >
              <div className="mx-auto h-28 w-28 overflow-hidden rounded-full border">
                <img
                  src={m.img || "/placeholder.svg"}
                  alt={`${m.name} — ${m.role}`}
                  className="h-full w-full object-cover"
                />
              </div>
              <h3 className="mt-3 font-semibold">{m.name}</h3>
              <p className="text-sm text-muted-foreground">{m.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
