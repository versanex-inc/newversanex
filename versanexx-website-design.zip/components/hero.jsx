"use client"
import { motion } from "framer-motion"
import { FiArrowRight, FiCheckCircle } from "react-icons/fi"
import Link from "next/link"

export default function Hero() {
  return (
    <section id="hero" className="relative overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 py-16 md:py-24 lg:py-28">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <motion.p
              initial={{ opacity: 0, y: 4 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.4 }}
              className="text-sm font-medium text-accent"
            >
              Versanexx • Software House
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, delay: 0.05 }}
              className="mt-2 text-pretty text-4xl font-semibold leading-tight md:text-5xl"
            >
              We design and build products that people love to use.
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mt-4 text-muted-foreground leading-relaxed"
            >
              High-performance web, mobile, AI, and cloud solutions. Human-centered, conversion-focused, and engineered
              for scale.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="mt-6 flex flex-wrap items-center gap-3"
            >
              <Link
                href="#contact"
                className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
              >
                Start a Project <FiArrowRight className="h-4 w-4" />
              </Link>
              <a
                href="#work"
                className="inline-flex items-center gap-2 rounded-md border px-4 py-2 text-sm font-medium"
              >
                View Portfolio
              </a>
            </motion.div>

            <ul className="mt-6 grid grid-cols-1 gap-2 text-sm text-muted-foreground sm:grid-cols-2">
              {[
                "100% responsive & accessible",
                "SEO & performance optimized",
                "Modern stack & best practices",
                "On-time delivery & support",
              ].map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <FiCheckCircle className="text-accent" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="aspect-[4/3] w-full overflow-hidden rounded-lg border">
              <img
                src="/team-collaborating-in-modern-software-studio.jpg"
                alt="Versanexx team collaborating in a modern studio"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="pointer-events-none absolute -left-6 -top-6 hidden h-20 w-20 rounded-xl bg-accent/30 md:block" />
            <div className="pointer-events-none absolute -bottom-6 -right-6 hidden h-24 w-24 rounded-xl bg-primary/20 md:block" />
          </motion.div>
        </div>
      </div>
    </section>
  )
}
