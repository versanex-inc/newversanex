"use client"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"
import { FiZap, FiClock, FiTrendingUp, FiShield } from "react-icons/fi"

const items = [
  { icon: FiZap, title: "Performance-first", desc: "Lighthouse-friendly, snappy UX, and scalable patterns." },
  { icon: FiClock, title: "On-time delivery", desc: "Reliable execution with transparent timelines." },
  { icon: FiTrendingUp, title: "Business impact", desc: "Design and engineering that move your metrics." },
  { icon: FiShield, title: "Security & quality", desc: "Best practices, audits, and solid testing culture." },
]

export default function Advantages() {
  return (
    <section id="why" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="Why Choose Us" title="Key advantages of partnering with Versanexx" />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {items.map(({ icon: Icon, title, desc }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.45, delay: i * 0.05 }}
              className="rounded-lg border p-5"
            >
              <div className="flex items-start gap-3">
                <div className="rounded-md bg-primary/10 p-2 text-primary">
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-semibold">{title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
