"use client"
import { motion } from "framer-motion"
import SectionHeading from "./section-heading"

const projects = Array.from({ length: 6 }).map((_, i) => ({
  title: `Project ${i + 1}`,
  image: `/placeholder.svg?height=600&width=900&query=high quality portfolio project ${i + 1}`,
  tag: i % 2 === 0 ? "Web App" : "Mobile",
}))

export default function Portfolio() {
  return (
    <section id="work" className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHeading eyebrow="Our Work" title="Selected projects & case studies" />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p, i) => (
            <motion.article
              key={p.title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.45, delay: i * 0.05 }}
              className="group overflow-hidden rounded-lg border"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={p.image || "/placeholder.svg"}
                  alt={`${p.title} preview`}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                />
              </div>
              <div className="flex items-center justify-between p-4">
                <h3 className="font-semibold">{p.title}</h3>
                <span className="rounded-full bg-accent/20 px-2 py-0.5 text-xs text-accent">{p.tag}</span>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}
